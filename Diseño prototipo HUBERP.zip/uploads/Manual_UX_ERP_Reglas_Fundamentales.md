# Manual Extendido de Reglas Fundamentales de Experiencia de Usuario (UX) para Aplicaciones ERP

## Reglas esenciales basadas en tendencias modernas y proyectadas al futuro para el desarrollo de aplicativos empresariales de vanguardia

**Versión:** 1.0 — Julio 2026
**Alcance:** Diseño, desarrollo y evaluación de interfaces de usuario en sistemas ERP (Enterprise Resource Planning) web, de escritorio y móviles.

---

## Índice

1. Introducción: por qué la UX es un factor crítico en los ERP
2. Principios rectores (fundamentos teóricos)
3. Sección A — Reglas de arquitectura de información y navegación
4. Sección B — Reglas de diseño de pantallas, formularios y datos
5. Sección C — Reglas de eficiencia operativa y productividad
6. Sección D — Reglas de prevención de errores y confianza
7. Sección E — Reglas de personalización y diseño basado en roles
8. Sección F — Reglas de accesibilidad e inclusión
9. Sección G — Reglas de rendimiento percibido
10. Sección H — Tendencias modernas y proyectadas al futuro (IA, conversacional, automatización, low-code)
11. Sección I — Diseño móvil y multiplataforma
12. Sección J — Medición, métricas y mejora continua de la UX
13. Checklist ejecutivo de cumplimiento
14. Referencias bibliográficas y web

---

## 1. Introducción: por qué la UX es un factor crítico en los ERP

Los sistemas ERP concentran los procesos más críticos de una organización: finanzas, inventarios, compras, ventas, manufactura, talento humano. Históricamente, su diseño priorizó la funcionalidad y la integridad de los datos por encima de la experiencia del usuario, lo que produjo interfaces densas, con curvas de aprendizaje largas, alta dependencia de capacitación y tasas elevadas de error humano.

**Fundamento:** La investigación de Forrester y de Nielsen Norman Group sobre "Enterprise UX" demuestra que la mala usabilidad en software empresarial tiene costos medibles: mayor tiempo de capacitación, más tickets de soporte, errores transaccionales, resistencia al cambio y baja adopción del sistema (uno de los principales factores de fracaso en implementaciones ERP según Panorama Consulting). A la inversa, una buena UX reduce el tiempo por tarea, disminuye errores y aumenta la adopción. El fenómeno de la **"consumerización del software empresarial"** (los usuarios esperan en el trabajo la misma calidad de experiencia que en sus aplicaciones personales) hace que la UX ya no sea opcional: es un requisito competitivo, tal como lo reflejan las inversiones de SAP (Fiori), Oracle (Redwood) y Microsoft (Fluent / Dynamics 365) en sistemas de diseño corporativos.

---

## 2. Principios rectores (fundamentos teóricos)

Todas las reglas de este manual se apoyan en un núcleo de principios validados por la investigación en interacción humano-computadora (HCI):

### 2.1 Las 10 heurísticas de usabilidad de Jakob Nielsen (1994, vigentes)
Visibilidad del estado del sistema; correspondencia entre el sistema y el mundo real; control y libertad del usuario; consistencia y estándares; prevención de errores; reconocer antes que recordar; flexibilidad y eficiencia de uso; diseño estético y minimalista; ayudar a reconocer, diagnosticar y recuperarse de errores; ayuda y documentación.

**Fundamento:** Son el marco de evaluación heurística más citado y validado empíricamente en la industria; siguen siendo la base de auditorías UX en software empresarial (NN/g).

### 2.2 Leyes cognitivas aplicables
- **Ley de Hick-Hyman:** el tiempo de decisión crece logarítmicamente con el número de opciones → menús y pantallas ERP deben limitar opciones visibles simultáneas.
- **Ley de Fitts:** el tiempo para alcanzar un objetivo depende de su tamaño y distancia → botones de acciones frecuentes deben ser grandes y estar cerca del flujo de trabajo.
- **Carga cognitiva (Sweller):** la memoria de trabajo humana es limitada (~4 elementos según Cowan, 2001; "7±2" según Miller, 1956) → agrupar, segmentar y revelar progresivamente.
- **Ley de Jakob (Nielsen):** los usuarios pasan la mayor parte del tiempo en otras aplicaciones; esperan que la suya funcione igual → adoptar patrones estándar de la industria.
- **Efecto de posición serial y Ley de Miller:** organizar la información en bloques (chunking).

### 2.3 Normas internacionales
- **ISO 9241-210:2019** (Diseño centrado en el ser humano para sistemas interactivos): define usabilidad como eficacia, eficiencia y satisfacción en un contexto de uso.
- **ISO 9241-110:2020** (Principios de interacción): idoneidad para la tarea, autodescriptividad, conformidad con expectativas, tolerancia a errores, controlabilidad, personalización.
- **WCAG 2.2 (W3C, 2023):** accesibilidad de contenidos web, aplicable legalmente en muchos países (p. ej., European Accessibility Act 2025, Sección 508 en EE. UU.).

---

## 3. Sección A — Reglas de arquitectura de información y navegación

### Regla A1. Diseñar por tareas y procesos, no por módulos de base de datos
La navegación debe reflejar los procesos de negocio del usuario ("crear orden de compra", "cerrar el mes contable"), no la estructura técnica de tablas o módulos del sistema.

**Fundamento:** ISO 9241-110 ("idoneidad para la tarea") y el principio de correspondencia con el mundo real de Nielsen. SAP Fiori formalizó este cambio con su enfoque *role-based, task-oriented*: descomponer megatransacciones en aplicaciones pequeñas orientadas a una tarea ("1 app, 1 tarea"), lo que redujo drásticamente los tiempos de ejecución frente a las transacciones clásicas de SAP GUI.

### Regla A2. Búsqueda global inteligente como vía principal de navegación
Todo ERP moderno debe ofrecer una búsqueda global omnipresente (patrón *command palette*, atajo tipo Ctrl+K) que permita encontrar registros, transacciones, reportes y acciones por texto libre, con tolerancia a errores tipográficos y sinónimos.

**Fundamento:** NN/g documenta que en sistemas densos la búsqueda supera a la navegación jerárquica en eficiencia para usuarios expertos. El patrón "command palette" (popularizado por herramientas como Slack, VS Code, Linear) se ha convertido en estándar de facto del software SaaS moderno y reduce el costo de interacción (número de clics y decisiones). La tendencia futura es que esta búsqueda sea semántica (basada en IA/embeddings) y acepte lenguaje natural.

### Regla A3. Jerarquía de máximo 3 niveles de profundidad
Ninguna función de uso frecuente debe requerir más de 3 niveles de navegación. Las funciones de uso diario deben ser accesibles en 1-2 clics desde la pantalla de inicio del rol.

**Fundamento:** Ley de Hick (más niveles = más decisiones = más tiempo) y estudios de NN/g sobre "cost of interaction". Las jerarquías profundas de los ERP legados (menús de 5-7 niveles en sistemas clásicos) son una de las quejas de usabilidad más documentadas en la literatura de adopción ERP.

### Regla A4. Página de inicio como panel de trabajo (workspace), no como menú
La pantalla inicial debe mostrar: tareas pendientes del usuario (bandeja de aprobaciones/acciones), indicadores clave de su rol, accesos directos a sus transacciones frecuentes y alertas. No debe ser un catálogo estático de módulos.

**Fundamento:** El patrón de "overview pages" y "spaces" de SAP Fiori y las "workspaces" de Oracle Redwood y Dynamics 365 responden al principio de visibilidad del estado del sistema (Nielsen #1) y al diseño proactivo: el sistema trae el trabajo al usuario en lugar de obligarlo a buscarlo. Esto reduce el tiempo de orientación al iniciar sesión.

### Regla A5. Migas de pan (breadcrumbs) y contexto persistente
En procesos de varios pasos y jerarquías de datos (empresa → sucursal → almacén → producto) el usuario debe ver siempre dónde está, de dónde vino y cómo regresar sin perder el trabajo.

**Fundamento:** Heurística de Nielsen #1 (visibilidad de estado) y #3 (control y libertad). Los breadcrumbs reducen la desorientación en sistemas jerárquicos profundos (NN/g, "Breadcrumbs: 11 Design Guidelines").

---

## 4. Sección B — Reglas de diseño de pantallas, formularios y datos

### Regla B1. Divulgación progresiva (progressive disclosure)
Mostrar por defecto solo los campos esenciales; agrupar lo avanzado en secciones colapsables o pasos posteriores. En un ERP típico, el 20 % de los campos cubre el 80 % de los casos de uso.

**Fundamento:** Concepto formalizado por Jakob Nielsen: la divulgación progresiva reduce la carga cognitiva y la tasa de error al enfocar la atención en lo relevante, sin sacrificar potencia para el usuario avanzado. Es coherente con la teoría de carga cognitiva de Sweller y el principio de diseño minimalista (Nielsen #8).

### Regla B2. Valores por defecto inteligentes y autocompletado
Todo campo que pueda deducirse del contexto (fecha, organización, moneda, almacén, condiciones de pago del cliente) debe venir prellenado y ser editable. Los catálogos deben ofrecer autocompletado con búsqueda difusa, no listas desplegables de cientos de elementos.

**Fundamento:** "Recognition rather than recall" (Nielsen #6) y reducción del costo de interacción. Estudios de formularios de Baymard Institute y NN/g muestran que los valores por defecto correctos son una de las intervenciones con mayor impacto en velocidad y precisión de captura. Tendencia futura: *defaults* predictivos generados por IA a partir del historial del usuario.

### Regla B3. Tablas de datos de alta densidad, pero legibles y manipulables
Las tablas (corazón del ERP) deben permitir: ordenar, filtrar por columna, buscar, fijar columnas, elegir columnas visibles, guardar vistas personalizadas, edición en línea (inline editing), selección múltiple con acciones masivas y exportación. La densidad visual debe ser configurable (cómodo/compacto).

**Fundamento:** Los usuarios expertos de ERP trabajan con volúmenes grandes de registros; NN/g ("Data Tables: Four Major User Tasks") identifica localizar, comparar, editar y actuar como tareas críticas. Las "vistas guardadas" implementan la heurística de flexibilidad y eficiencia (Nielsen #7). Los sistemas de diseño empresariales (Fiori, Fluent, Carbon de IBM) dedican componentes de tabla especializados precisamente porque es el componente más usado del software empresarial.

### Regla B4. Validación en línea, inmediata y constructiva
Validar campo por campo en el momento de la captura (formato, rangos, existencia del registro), con mensajes junto al campo, en lenguaje humano, que digan qué pasó y cómo corregirlo. Nunca validar solo al enviar el formulario completo.

**Fundamento:** Prevención de errores (Nielsen #5) y recuperación de errores (Nielsen #9). La investigación de Luke Wroblewski ("Web Form Design", 2008) y de Baymard demuestra que la validación en línea reduce errores y tiempo de completado frente a la validación posterior al envío.

### Regla B5. Tipografía, contraste y jerarquía visual disciplinada
Usar una escala tipográfica limitada (3-4 tamaños), contraste mínimo 4.5:1 para texto normal (WCAG), alineación numérica a la derecha con formato regional, y espacios en blanco como herramienta de agrupación (principios Gestalt de proximidad y similitud).

**Fundamento:** WCAG 2.2 (criterio 1.4.3) y principios Gestalt de percepción (Wertheimer). En interfaces densas, la jerarquía visual es lo que permite escanear en lugar de leer; NN/g documenta patrones de escaneo en "F-pattern" y la importancia del chunking visual.

### Regla B6. Estados vacíos, de carga y de error diseñados intencionalmente
Toda pantalla debe tener diseñados sus estados: vacío (con guía de primer uso y llamado a la acción), cargando (skeleton screens), sin resultados (con sugerencias) y error (con causa y acción de recuperación).

**Fundamento:** Visibilidad del estado del sistema (Nielsen #1). Los "empty states" son una oportunidad de onboarding documentada por NN/g y Material Design; los *skeleton screens* mejoran el rendimiento percibido frente a los spinners (investigación de Luke Wroblewski y estudios de percepción de espera).

---

## 5. Sección C — Reglas de eficiencia operativa y productividad

### Regla C1. Optimizar para el usuario experto sin castigar al novato
Ofrecer aceleradores: atajos de teclado completos (navegación, guardar, crear, buscar), captura de datos sin soltar el teclado (tab-order lógico), plantillas de documentos, duplicar registros, acciones masivas y macros/automatizaciones personales.

**Fundamento:** Heurística de Nielsen #7 (flexibilidad y eficiencia de uso): los aceleradores invisibles para el novato aumentan la velocidad del experto. En contextos de captura intensiva (facturación, inventarios), el uso de teclado es entre 2 y 5 veces más rápido que el mouse para usuarios entrenados (estudios clásicos de GOMS/KLM de Card, Moran y Newell, 1983).

### Regla C2. Minimizar los cambios de contexto
Permitir completar tareas frecuentes sin abandonar la pantalla actual: paneles laterales, vistas rápidas (quick view) de registros relacionados, creación rápida de registros dependientes (p. ej., crear un cliente desde la orden de venta) y edición en ventanas modales solo cuando sea imprescindible.

**Fundamento:** Cada cambio de contexto tiene un costo de reorientación cognitiva documentado en la literatura de atención e interrupciones (Mark, González et al., UC Irvine: recuperar el foco tras una interrupción toma en promedio más de 20 minutos en trabajo de oficina). Los patrones *master-detail* y *side panel* de Fiori y Fluent existen para esto.

### Regla C3. Guardado automático y trabajo recuperable
Ningún usuario debe perder trabajo por un cierre de sesión, un fallo de red o un error. Implementar borradores automáticos, recuperación de sesión y advertencias antes de descartar cambios.

**Fundamento:** Control y libertad del usuario (Nielsen #3) y tolerancia a errores (ISO 9241-110). La pérdida de datos capturados es uno de los eventos que más daña la confianza en el sistema (NN/g, "Error Message Guidelines"). El estándar de facto del software moderno (Google Docs, Notion) ya creó esta expectativa en los usuarios (Ley de Jakob).

### Regla C4. Flujos de aprobación de un toque y desde cualquier dispositivo
Las aprobaciones (compras, gastos, vacaciones) deben poder ejecutarse desde la bandeja de tareas, correo o móvil con el contexto suficiente para decidir (montos, historial, política aplicable) sin abrir el documento completo.

**Fundamento:** Las aprobaciones son la interacción ERP más frecuente entre mandos medios y directivos; su fricción retrasa procesos completos. El patrón "inbox de aprobaciones" (SAP My Inbox, Workday, Dynamics 365 Approvals en Teams) demuestra la tendencia a llevar la decisión al lugar donde el usuario ya está.

### Regla C5. Diseño para la interrupción
Asumir que el usuario será interrumpido: los procesos largos deben poder pausarse y retomarse, indicar el paso actual (wizard con progreso), y las listas de trabajo deben marcar qué está pendiente, en proceso y terminado.

**Fundamento:** Investigación sobre trabajo interrumpido (Mark et al., CHI) y visibilidad de estado (Nielsen #1). Los *wizards* con indicadores de progreso reducen abandono y errores en procesos multi-paso (NN/g, "Wizards: Definition and Design Recommendations").

---

## 6. Sección D — Reglas de prevención de errores y confianza

### Regla D1. Prevenir antes que corregir
Deshabilitar (con explicación) acciones no válidas en el contexto, usar restricciones de captura (selectores de fecha, catálogos controlados), advertir sobre consecuencias antes de acciones destructivas y aplicar el patrón de confirmación proporcional al riesgo.

**Fundamento:** Nielsen #5 y el concepto de *forcing functions* y *constraints* de Don Norman ("The Design of Everyday Things", 1988/2013). En ERP, un error transaccional puede propagarse a contabilidad, inventario y facturación; el costo de prevenir es órdenes de magnitud menor que el de corregir.

### Regla D2. Deshacer (undo) en lugar de confirmar todo
Preferir acciones reversibles con opción de deshacer (patrón "snackbar de undo") sobre diálogos de confirmación repetitivos, reservando la confirmación explícita (escribir el nombre, doble verificación) para acciones verdaderamente irreversibles o de alto impacto (cierre de periodo, anulación fiscal, eliminación definitiva).

**Fundamento:** Los diálogos de confirmación constantes producen "ceguera de confirmación": el usuario aprende a aceptarlos sin leer (NN/g, "Confirmation Dialogs Can Prevent User Errors — If Not Overused"). El undo respeta el control del usuario (Nielsen #3) sin frenar el flujo.

### Regla D3. Mensajes de error con causa, consecuencia y solución
Todo mensaje de error debe decir en lenguaje del negocio: qué pasó, por qué, y qué hacer para resolverlo (idealmente con la acción incluida en el propio mensaje). Nunca mostrar códigos técnicos como único contenido; los códigos van como detalle secundario para soporte.

**Fundamento:** Nielsen #9 y las guías de mensajes de error de NN/g. Los mensajes crípticos son un generador directo de tickets de soporte y desconfianza; los mensajes accionables convierten el error en un paso más del flujo.

### Regla D4. Transparencia y auditabilidad visible
Mostrar quién hizo qué y cuándo (historial de cambios legible), el estado del documento en su ciclo de vida (borrador → aprobado → contabilizado) con lenguaje y color consistentes, y trazabilidad entre documentos relacionados (orden → recepción → factura → pago).

**Fundamento:** La confianza en sistemas empresariales depende de la trazabilidad (requisitos de auditoría SOX/normas locales) y la visibilidad de estado (Nielsen #1). El "document flow" visual de SAP y los timelines de actividad de Salesforce/Dynamics son patrones consolidados que reducen consultas entre áreas.

### Regla D5. Consistencia total mediante un sistema de diseño (design system)
Todos los módulos deben usar los mismos componentes, terminología, patrones de interacción, iconografía y comportamiento. El sistema de diseño debe estar documentado, versionado y con componentes reutilizables en código (tokens de diseño incluidos).

**Fundamento:** Consistencia y estándares (Nielsen #4) e ISO 9241-110 (conformidad con expectativas). La inconsistencia entre módulos multiplica la curva de aprendizaje: lo aprendido en un módulo debe transferirse a los demás. Los sistemas de diseño empresariales (SAP Fiori, Oracle Redwood, Microsoft Fluent 2, IBM Carbon, Atlassian Design System) son la práctica estándar de la industria y reducen además el costo de desarrollo y mantenimiento (Forrester, "The ROI of Design Systems").

---

## 7. Sección E — Reglas de personalización y diseño basado en roles

### Regla E1. Experiencias por rol, no una interfaz única
Cada rol (cajero, comprador, contador, gerente, operario de almacén) debe recibir una pantalla de inicio, navegación, indicadores y permisos alineados a sus tareas. Lo que el usuario no puede o no necesita usar, no debe verse.

**Fundamento:** Principio central de SAP Fiori ("role-based") y de Oracle Redwood. Reduce la Ley de Hick (menos opciones irrelevantes), el riesgo de error y el tiempo de capacitación. La seguridad basada en roles (RBAC) debe reflejarse también en la capa visual, no solo en permisos de backend.

### Regla E2. Personalización por el usuario final sin programar
Permitir al usuario: reordenar y ocultar columnas, guardar filtros y vistas, fijar favoritos, configurar sus widgets del panel inicial y definir sus notificaciones, todo con opción de restaurar valores por defecto.

**Fundamento:** ISO 9241-110 (principio de individualización) y Nielsen #7. La investigación de adopción de software empresarial muestra que la apropiación ("hacerlo mío") aumenta la satisfacción y el uso sostenido. La restauración de defaults protege contra la auto-configuración dañina.

### Regla E3. Adaptación contextual e inteligente
La interfaz debe adaptarse al contexto: sugerir las acciones más probables según el momento del mes (cierre contable), el historial del usuario y el estado del documento. Proyección a futuro: interfaces generativas/adaptativas que reorganizan contenido según la intención detectada.

**Fundamento:** Tendencia documentada por Gartner (hiperautomatización y "composable applications") y NN/g sobre interfaces adaptativas. Los "insight cards" de Oracle Redwood y las sugerencias de Copilot en Dynamics 365 son implementaciones actuales; la literatura advierte equilibrar adaptación con previsibilidad (la interfaz no debe "moverse sola" de forma impredecible, lo que violaría la consistencia).

---

## 8. Sección F — Reglas de accesibilidad e inclusión

### Regla F1. Cumplimiento WCAG 2.2 nivel AA como mínimo obligatorio
Contraste suficiente, navegación completa por teclado, foco visible, etiquetas y roles ARIA correctos, textos alternativos, no depender solo del color para comunicar estado, objetivos táctiles de al menos 24×24 px (criterio 2.5.8 de WCAG 2.2).

**Fundamento:** WCAG 2.2 (W3C, 2023) es el estándar internacional; su cumplimiento es exigencia legal creciente (European Accessibility Act, vigente desde junio de 2025; ADA/Sección 508 en EE. UU.; normas locales en Latinoamérica). Además, la accesibilidad beneficia a todos los usuarios (curb-cut effect): el buen contraste y el teclado completo mejoran la productividad general.

### Regla F2. Internacionalización y localización reales
Soportar formatos regionales de fecha, número y moneda; traducciones completas (no parciales) con terminología contable/fiscal local; expansión de texto (el alemán o el español ocupan hasta 30-40 % más que el inglés); y consideraciones RTL si aplica.

**Fundamento:** ISO 9241 (contexto de uso) y guías de internacionalización del W3C. En ERP, un formato de número mal localizado (punto vs. coma decimal) puede producir errores financieros graves, no solo molestias estéticas.

### Regla F3. Lenguaje claro y del dominio del usuario
Usar la terminología del negocio local (factura, remisión, kardex, según el país), evitar jerga técnica del sistema y mantener un glosario único aplicado de forma consistente en interfaz, mensajes, ayuda y reportes.

**Fundamento:** Correspondencia con el mundo real (Nielsen #2) y plain language guidelines (PlainLanguage.gov, W3C). La terminología inconsistente entre módulos es una fuente medible de errores de interpretación y capacitación redundante.

---

## 9. Sección G — Reglas de rendimiento percibido

### Regla G1. Presupuestos de rendimiento estrictos
Objetivos de referencia: respuesta a interacción < 100 ms (percepción de instantaneidad), transiciones < 1 s (mantiene el flujo de pensamiento), operaciones largas > 1 s con indicador de progreso, y > 10 s con posibilidad de continuar trabajando y notificación al terminar.

**Fundamento:** Los umbrales 0.1 s / 1 s / 10 s provienen de la investigación clásica de Robert B. Miller (1968) y fueron consolidados por Jakob Nielsen ("Usability Engineering", 1993; "Response Times: The 3 Important Limits"). Métricas modernas equivalentes: Core Web Vitals de Google (INP < 200 ms, LCP < 2.5 s).

### Regla G2. Diseñar la espera
Cuando la espera es inevitable: skeleton screens en carga de pantallas, indicadores de progreso determinados cuando se conoce la duración, procesamiento en segundo plano con centro de notificaciones para trabajos largos (cálculo de nómina, MRP, cierres), y optimistic UI para acciones de bajo riesgo.

**Fundamento:** La percepción del tiempo de espera es maleable (investigación de psicología del tiempo de espera, David Maister, "The Psychology of Waiting Lines"); los skeleton screens y el progreso visible reducen la percepción de lentitud y el abandono (NN/g, "Progress Indicators").

### Regla G3. Trabajar con datos masivos sin degradar la experiencia
Paginación o scroll virtual para listas grandes, carga diferida (lazy loading), filtros aplicados en servidor, y agregados precalculados para tableros. El usuario nunca debe poder "tumbar" su sesión al abrir una lista de un millón de registros.

**Fundamento:** Principio de tolerancia del sistema y práctica estándar de ingeniería front-end para aplicaciones data-heavy (documentación de virtualización de listas en frameworks modernos; guías de rendimiento de Google web.dev).

---

## 10. Sección H — Tendencias modernas y proyectadas al futuro

### Regla H1. IA asistiva integrada en el flujo (copilotos)
Integrar asistentes de IA que: respondan preguntas sobre los datos en lenguaje natural ("¿cuánto vendimos en marzo por sucursal?"), generen borradores (descripciones de productos, correos de cobranza, asientos propuestos), expliquen variaciones ("¿por qué subió este costo?") y guíen procesos. La IA debe ser **asistiva y supervisada**: propone, el humano dispone, con visibilidad de la fuente de los datos.

**Fundamento:** Es la tendencia dominante 2023-2026 en ERP: SAP Joule, Microsoft Copilot para Dynamics 365, Oracle AI Agents en Fusion Applications. Gartner proyecta que los agentes de IA participarán en una proporción creciente de las decisiones operativas cotidianas. Las guías de diseño humano-IA (Microsoft "Guidelines for Human-AI Interaction", Amershi et al., CHI 2019; y "People + AI Guidebook" de Google PAIR) establecen los principios: dejar claro qué puede hacer el sistema, cuán bien lo hace, permitir corrección eficiente y aprender del feedback.

### Regla H2. Interfaces conversacionales y multimodales como capa complementaria
Permitir ejecutar consultas y transacciones simples por chat o voz (crear un pedido dictando, consultar existencias desde el móvil en almacén), manteniendo siempre la interfaz gráfica como respaldo y para tareas complejas.

**Fundamento:** El lenguaje natural reduce la barrera de entrada para usuarios ocasionales del ERP (la mayoría de empleados de una organización). La investigación de NN/g sobre interfaces conversacionales advierte sus límites (descubribilidad, ambigüedad), por lo que la regla las define como capa complementaria y no sustituta.

### Regla H3. Automatización visible y controlable (hiperautomatización)
Automatizar lo repetitivo (conciliaciones, matching de facturas, reabastecimiento) pero con: registro visible de lo que la automatización hizo, umbrales configurables, bandeja de excepciones para intervención humana y capacidad de desactivar reglas.

**Fundamento:** Gartner (hiperautomatización como tendencia estratégica desde 2020) y el principio de *human-in-the-loop*. La literatura de automatización (Bainbridge, "Ironies of Automation", 1983) advierte que la automatización opaca degrada la capacidad del humano para supervisar; la visibilidad es el antídoto.

### Regla H4. Analítica embebida en el punto de decisión
Los indicadores y visualizaciones deben aparecer dentro del flujo de trabajo (margen del pedido mientras se captura, riesgo crediticio del cliente en la pantalla de venta), no solo en un módulo de reportes separado. Toda cifra agregada debe permitir el drill-down hasta el documento origen.

**Fundamento:** El concepto de *embedded analytics* / *decision intelligence* (Gartner) y los principios de visualización de datos de Stephen Few ("Information Dashboard Design", 2006) y Edward Tufte ("The Visual Display of Quantitative Information", 1983): mostrar el dato en el contexto donde se decide, maximizar la relación tinta-datos y evitar decoración que no informa.

### Regla H5. Arquitectura composable y extensible con low-code
Diseñar el ERP como conjunto de capacidades componibles (APIs, eventos, componentes UI reutilizables) que permita a las empresas construir pantallas y flujos propios con herramientas low-code/no-code manteniendo los estándares del sistema de diseño.

**Fundamento:** Gartner ("Composable ERP", desde 2020) proyecta que las organizaciones exigirán adaptar el ERP a su proceso y no al revés. El low-code gobernado (con guardrails de diseño y seguridad) resuelve la tensión histórica entre estandarización y personalización que encarecía las implementaciones.

### Regla H6. Notificaciones inteligentes y gestión de la atención
Consolidar notificaciones en un centro único, clasificarlas por urgencia y accionabilidad, permitir configuración fina por el usuario y agrupar (digest) lo no urgente. Prohibido el spam de notificaciones: cada una debe permitir actuar directamente.

**Fundamento:** La economía de la atención y la investigación sobre interrupciones (Mark et al.) muestran el costo real de cada notificación. El patrón "actionable notifications" y los centros de notificaciones son estándar en Fluent/Material; la tendencia futura es la priorización por IA según impacto para el rol.

### Regla H7. Confianza, privacidad y ética del dato como parte de la UX
Explicar con claridad qué datos usa la IA y para qué, permitir opt-out donde aplique, señalizar contenido generado por IA, y diseñar contra patrones oscuros (dark patterns).

**Fundamento:** Regulación emergente (EU AI Act, 2024; leyes de protección de datos como GDPR y sus equivalentes latinoamericanos) y guías de IA responsable (OECD AI Principles; NIST AI Risk Management Framework, 2023). La transparencia es además un requisito de adopción: los usuarios no delegan en lo que no entienden.

---

## 11. Sección I — Diseño móvil y multiplataforma

### Regla I1. Móvil para tareas de campo y decisión, escritorio para captura intensiva
Definir explícitamente qué tareas son *mobile-first* (aprobaciones, consultas, inventarios físicos con escáner, evidencias fotográficas, firma en entrega) y optimizarlas para una mano, con objetivos táctiles ≥ 44-48 px y flujos de máximo 2-3 pantallas.

**Fundamento:** Guías de plataformas (Apple Human Interface Guidelines: 44 pt; Material Design: 48 dp) y la evidencia de que el uso móvil del ERP es situacional, no sustitutivo del escritorio. Forzar la paridad total de funciones en móvil produce interfaces inutilizables (NN/g, "Mobile UX").

### Regla I2. Continuidad entre dispositivos y funcionamiento sin conexión
El trabajo iniciado en un dispositivo debe poder continuarse en otro. Las funciones de campo (toma de inventario, rutas de entrega) deben operar offline con sincronización robusta y resolución de conflictos comprensible.

**Fundamento:** Expectativa creada por los ecosistemas de consumo (Ley de Jakob) y requisito operativo real en almacenes, plantas y zonas con conectividad intermitente. Los patrones offline-first están documentados en la literatura de PWA (Google web.dev) y en las apps industriales de SAP/Oracle.

### Regla I3. Diseño responsivo con puntos de quiebre orientados al contenido
La misma aplicación web debe reorganizarse con sentido (tablas → tarjetas en pantallas pequeñas; paneles laterales → pantallas apiladas) sin ocultar capacidades críticas arbitrariamente.

**Fundamento:** Práctica estándar de diseño responsivo (Marcotte, "Responsive Web Design", 2010) y componentes adaptativos de los design systems empresariales.

---

## 12. Sección J — Medición, métricas y mejora continua de la UX

### Regla J1. Instrumentar la experiencia con métricas objetivas
Medir de forma continua: tiempo por tarea clave, tasa de éxito, tasa de error, uso de funciones, rutas de navegación reales, abandono de flujos y rendimiento técnico percibido. Complementar con métricas subjetivas: SUS (System Usability Scale), NPS interno, encuestas de esfuerzo (CES).

**Fundamento:** ISO 9241-11 define usabilidad en términos medibles (eficacia, eficiencia, satisfacción). El SUS (Brooke, 1996) es el cuestionario de usabilidad más validado (Bangor, Kortum & Miller, 2008). El framework HEART de Google (Rodden, Hutchinson & Fu, CHI 2010: Happiness, Engagement, Adoption, Retention, Task success) ofrece un modelo práctico para elegir métricas por objetivo.

### Regla J2. Investigación con usuarios reales y pruebas periódicas
Realizar pruebas de usabilidad moderadas con usuarios de cada rol antes de liberar cambios relevantes (5 usuarios detectan la mayoría de los problemas graves por ronda, Nielsen 2000), más entrevistas contextuales en el puesto de trabajo (contextual inquiry) para entender el proceso real.

**Fundamento:** Nielsen & Landauer (1993) y Nielsen ("Why You Only Need to Test with 5 Users", 2000) sobre el rendimiento decreciente de las muestras grandes en pruebas formativas; Beyer & Holtzblatt ("Contextual Design", 1998) sobre la observación en contexto, crítica en ERP donde el trabajo real difiere del proceso documentado.

### Regla J3. Onboarding y ayuda dentro del producto
Sustituir manuales externos por: recorridos guiados contextuales la primera vez, ayuda embebida por campo/pantalla, tooltips ricos, documentación buscable dentro de la app y (tendencia) asistente de IA que responde "¿cómo hago X?" con pasos ejecutables.

**Fundamento:** Nielsen #10 (ayuda y documentación accesible en contexto). La industria de Digital Adoption Platforms (WalkMe, Pendo, Whatfix) creció precisamente sobre la brecha de adopción de los ERP; integrar esa capa nativamente reduce dependencia de capacitación formal y tickets de soporte.

### Regla J4. Gobernanza de UX y ciclo de mejora continua
Establecer: propietario de la experiencia (rol formal), auditorías heurísticas periódicas, tablero de deuda de UX priorizada por impacto, y proceso de cambio que evalúe el costo de reentrenamiento antes de alterar patrones establecidos.

**Fundamento:** ISO 9241-210 exige un proceso iterativo centrado en el humano, no un evento único. Los modelos de madurez UX (NN/g, "UX Maturity Model", 2021) muestran que sin gobernanza formal las mejoras no se sostienen. En ERP, cambiar patrones sin gestión de cambio destruye la eficiencia adquirida de los usuarios expertos.

---

## 13. Checklist ejecutivo de cumplimiento

| # | Verificación rápida | Sección |
|---|---|---|
| 1 | La navegación refleja procesos de negocio y roles, no módulos técnicos | A1, E1 |
| 2 | Existe búsqueda global inteligente accesible con atajo de teclado | A2 |
| 3 | Toda función frecuente está a ≤ 3 niveles / 1-2 clics | A3 |
| 4 | La pantalla de inicio muestra tareas, KPIs y accesos del rol | A4 |
| 5 | Los formularios usan divulgación progresiva y defaults inteligentes | B1, B2 |
| 6 | Las tablas permiten filtrar, ordenar, vistas guardadas y acciones masivas | B3 |
| 7 | Validación en línea con mensajes accionables en lenguaje humano | B4, D3 |
| 8 | Estados vacío/carga/error diseñados en todas las pantallas | B6 |
| 9 | Atajos de teclado y captura sin mouse en pantallas de alto volumen | C1 |
| 10 | Guardado automático y recuperación de trabajo | C3 |
| 11 | Undo disponible; confirmaciones solo para lo irreversible | D2 |
| 12 | Historial de cambios y flujo de documentos visible | D4 |
| 13 | Design system único documentado y aplicado en todos los módulos | D5 |
| 14 | Personalización de vistas/columnas/favoritos por usuario, con reset | E2 |
| 15 | Cumplimiento WCAG 2.2 AA verificado con auditoría | F1 |
| 16 | Localización completa de formatos, moneda y terminología | F2 |
| 17 | Interacciones < 100 ms; procesos largos en segundo plano con aviso | G1, G2 |
| 18 | IA asistiva con supervisión humana y transparencia de fuentes | H1, H7 |
| 19 | Analítica embebida con drill-down en el punto de decisión | H4 |
| 20 | Tareas móviles de campo definidas y con soporte offline | I1, I2 |
| 21 | Métricas de UX instrumentadas (SUS, tiempo por tarea, tasa de error) | J1 |
| 22 | Pruebas de usabilidad periódicas con usuarios reales de cada rol | J2 |
| 23 | Onboarding y ayuda contextual dentro del producto | J3 |
| 24 | Gobernanza formal de UX y gestión de cambio de patrones | J4 |

---

## 14. Referencias bibliográficas y web

### Libros y publicaciones académicas

1. Nielsen, J. (1993). *Usability Engineering*. Academic Press.
2. Nielsen, J. (1994). "10 Usability Heuristics for User Interface Design". Nielsen Norman Group. https://www.nngroup.com/articles/ten-usability-heuristics/
3. Norman, D. (2013). *The Design of Everyday Things* (edición revisada). Basic Books.
4. Miller, G. A. (1956). "The Magical Number Seven, Plus or Minus Two". *Psychological Review*, 63(2), 81–97.
5. Cowan, N. (2001). "The magical number 4 in short-term memory". *Behavioral and Brain Sciences*, 24(1), 87–114.
6. Sweller, J. (1988). "Cognitive Load During Problem Solving". *Cognitive Science*, 12(2), 257–285.
7. Hick, W. E. (1952). "On the rate of gain of information". *Quarterly Journal of Experimental Psychology*, 4(1), 11–26.
8. Fitts, P. M. (1954). "The information capacity of the human motor system". *Journal of Experimental Psychology*, 47(6), 381–391.
9. Card, S., Moran, T., & Newell, A. (1983). *The Psychology of Human-Computer Interaction*. Lawrence Erlbaum.
10. Miller, R. B. (1968). "Response time in man-computer conversational transactions". *Proceedings AFIPS Fall Joint Computer Conference*, 267–277.
11. Brooke, J. (1996). "SUS: A 'quick and dirty' usability scale". En *Usability Evaluation in Industry*. Taylor & Francis.
12. Bangor, A., Kortum, P., & Miller, J. (2008). "An Empirical Evaluation of the System Usability Scale". *International Journal of Human–Computer Interaction*, 24(6), 574–594.
13. Nielsen, J., & Landauer, T. K. (1993). "A mathematical model of the finding of usability problems". *Proceedings of ACM INTERCHI'93*, 206–213.
14. Rodden, K., Hutchinson, H., & Fu, X. (2010). "Measuring the User Experience on a Large Scale (HEART framework)". *Proceedings of CHI 2010*. Google Research.
15. Amershi, S., et al. (2019). "Guidelines for Human-AI Interaction". *Proceedings of CHI 2019*. Microsoft Research. https://www.microsoft.com/en-us/research/publication/guidelines-for-human-ai-interaction/
16. Bainbridge, L. (1983). "Ironies of Automation". *Automatica*, 19(6), 775–779.
17. Mark, G., González, V. M., & Harris, J. (2005). "No Task Left Behind? Examining the Nature of Fragmented Work". *Proceedings of CHI 2005*.
18. Beyer, H., & Holtzblatt, K. (1998). *Contextual Design: Defining Customer-Centered Systems*. Morgan Kaufmann.
19. Wroblewski, L. (2008). *Web Form Design: Filling in the Blanks*. Rosenfeld Media.
20. Few, S. (2006). *Information Dashboard Design*. O'Reilly Media.
21. Tufte, E. (1983). *The Visual Display of Quantitative Information*. Graphics Press.
22. Maister, D. (1985). "The Psychology of Waiting Lines". En *The Service Encounter*. Lexington Books.
23. Marcotte, E. (2010). "Responsive Web Design". *A List Apart*. https://alistapart.com/article/responsive-web-design/
24. Wertheimer, M. (1923). "Laws of Organization in Perceptual Forms" (principios Gestalt). Traducción en Ellis, W. (1938), *A Source Book of Gestalt Psychology*.

### Normas y estándares

25. ISO 9241-210:2019. *Ergonomics of human-system interaction — Part 210: Human-centred design for interactive systems*. https://www.iso.org/standard/77520.html
26. ISO 9241-110:2020. *Part 110: Interaction principles*. https://www.iso.org/standard/75258.html
27. ISO 9241-11:2018. *Part 11: Usability: Definitions and concepts*. https://www.iso.org/standard/63500.html
28. W3C (2023). *Web Content Accessibility Guidelines (WCAG) 2.2*. https://www.w3.org/TR/WCAG22/
29. Unión Europea (2019/882). *European Accessibility Act*. https://eur-lex.europa.eu/eli/dir/2019/882/oj
30. Unión Europea (2024). *EU Artificial Intelligence Act*. https://eur-lex.europa.eu/eli/reg/2024/1689/oj
31. NIST (2023). *AI Risk Management Framework (AI RMF 1.0)*. https://www.nist.gov/itl/ai-risk-management-framework
32. OECD (2019, act. 2024). *OECD AI Principles*. https://oecd.ai/en/ai-principles

### Sistemas de diseño y guías de fabricantes ERP

33. SAP. *SAP Fiori Design Guidelines*. https://experience.sap.com/fiori-design/
34. Oracle. *Redwood Design System*. https://www.oracle.com/webfolder/technetwork/tutorials/tutorial/cloud/redwood/index.html y https://redwood.oracle.com/
35. Microsoft. *Fluent 2 Design System*. https://fluent2.microsoft.design/
36. Microsoft. *Dynamics 365 y Copilot — documentación*. https://learn.microsoft.com/dynamics365/
37. IBM. *Carbon Design System*. https://carbondesignsystem.com/
38. Google. *Material Design 3*. https://m3.material.io/
39. Apple. *Human Interface Guidelines*. https://developer.apple.com/design/human-interface-guidelines/
40. Google PAIR. *People + AI Guidebook*. https://pair.withgoogle.com/guidebook/
41. SAP. *SAP Joule (asistente de IA)*. https://www.sap.com/products/artificial-intelligence/ai-assistant.html

### Artículos y recursos web de investigación aplicada

42. Nielsen Norman Group. *Progressive Disclosure*. https://www.nngroup.com/articles/progressive-disclosure/
43. Nielsen Norman Group. *Response Times: The 3 Important Limits*. https://www.nngroup.com/articles/response-times-3-important-limits/
44. Nielsen Norman Group. *Why You Only Need to Test with 5 Users*. https://www.nngroup.com/articles/why-you-only-need-to-test-with-5-users/
45. Nielsen Norman Group. *Error Message Guidelines*. https://www.nngroup.com/articles/error-message-guidelines/
46. Nielsen Norman Group. *Confirmation Dialogs Can Prevent User Errors — If Not Overused*. https://www.nngroup.com/articles/confirmation-dialog/
47. Nielsen Norman Group. *Data Tables: Four Major User Tasks*. https://www.nngroup.com/articles/data-tables/
48. Nielsen Norman Group. *Breadcrumbs: 11 Design Guidelines*. https://www.nngroup.com/articles/breadcrumbs/
49. Nielsen Norman Group. *Wizards: Definition and Design Recommendations*. https://www.nngroup.com/articles/wizards/
50. Nielsen Norman Group. *The UX Maturity Model* (2021). https://www.nngroup.com/articles/ux-maturity-model/
51. Nielsen Norman Group. *Jakob's Law of Internet User Experience*. https://www.nngroup.com/videos/jakobs-law-internet-ux/
52. Google. *Core Web Vitals*. https://web.dev/articles/vitals
53. Baymard Institute. *Form Usability Research*. https://baymard.com/blog
54. Gartner. *Top Strategic Technology Trends* (hiperautomatización, composable applications, IA agéntica; ediciones 2020–2026). https://www.gartner.com/en/information-technology/insights/top-technology-trends
55. Panorama Consulting Group. *ERP Report* (informes anuales sobre adopción y fracaso de implementaciones). https://www.panorama-consulting.com/resource-center/erp-report/
56. Forrester Research. *The Six Steps For Justifying Better UX* y estudios de ROI de diseño. https://www.forrester.com/
57. Laws of UX (recopilación de leyes cognitivas aplicadas, Jon Yablonski). https://lawsofux.com/
58. PlainLanguage.gov. *Federal Plain Language Guidelines*. https://www.plainlanguage.gov/guidelines/

> **Nota sobre las referencias:** los enlaces fueron verificados con corte de conocimiento en enero de 2026; algunos recursos (especialmente informes de Gartner y Forrester) requieren suscripción. Se recomienda verificar las versiones más recientes de normas y guías, ya que WCAG, los design systems y la regulación de IA evolucionan continuamente.

---

*Fin del manual. Este documento puede adoptarse como estándar interno de diseño y desarrollo, complementándose con el design system propio de la organización y auditorías periódicas de cumplimiento (sección 13).*
